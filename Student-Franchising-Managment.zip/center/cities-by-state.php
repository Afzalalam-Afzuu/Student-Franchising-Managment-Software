                        <?php
                        require_once "db.php";
                        $dist=$_POST['state_id'];
                        $result = mysqli_query($con,"SELECT * FROM place where state='$dist'");
                        while($row = mysqli_fetch_array($result)) {
                            $datatype= $row['data_type'];
                            if($datatype=='DISTRICT'){
                            ?>
                        <option value="<?php echo $row['dist'];?>"><?php echo $row["dist"];?></option>
                        <?php
                            }
                            else{
                                
                            }
                        }
                        ?>