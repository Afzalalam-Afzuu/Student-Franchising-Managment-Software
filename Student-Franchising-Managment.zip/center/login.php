<?php
$msg = false;
require('db.php');
session_start();

if (isset($_POST['submit'])) {
    $username = stripslashes($_POST['username']);    
    $username = mysqli_real_escape_string($con, $username);
    $password = stripslashes($_POST['password']);
    $password = mysqli_real_escape_string($con, $password);
    // Check user is exist in the database
    $query    = "SELECT * FROM users WHERE logid='$username'   AND logpwd='$password'";
    $result = mysqli_query($con, $query);
    $rows = mysqli_num_rows($result);
    if ($rows == 1) {
        $_SESSION['username'] = $username;
        
        header("Location: account.php");    
    } else {
        $msg = true; 
    }
} else { 
    
    
}
?>

<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	<title>Users | Ashoka India	</title>
	<meta name="description" content="Pratistha Computer Academy (PCA) train and groom students to get employed with much advanced skills required to work anywhere in the world. PCA has implemented Teaching – Learning process by which students have more practical knowledge on the subject they learn for a competitive employability and professional capability."/>
  
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Playball' rel='stylesheet' type='text/css'>
        
	<link href="https://app.pcaedu.in/favicon.ico" type="image/x-icon" rel="icon" />
	<link href="https://app.pcaedu.in/favicon.ico" type="image/x-icon" rel="shortcut icon" />
	<link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
	<link rel="stylesheet" type="text/css" href="css/animate.min.css" />
	<link rel="stylesheet" type="text/css" href="css/owl.transitions.css" />
	<link rel="stylesheet" type="text/css" href="css/prettyPhoto.css" />
	<link rel="stylesheet" type="text/css" href="css/main.css" />
	<link rel="stylesheet" type="text/css" href="css/responsive.css" />
	<script type="text/javascript" src="../js/jquery.js"></script>
 
<link rel="stylesheet" href="css/font-awesome.min.css">

</head>
	
	<body id="top">
    		<div class="preloader">
			<div class="sk-spinner sk-spinner-wave">
     	 		<div class="sk-rect1"></div>
       			<div class="sk-rect2"></div>
       			<div class="sk-rect3"></div>
      	 		<div class="sk-rect4"></div>
      			<div class="sk-rect5"></div>
     		</div>
    	</div>
    	
		<header id="header">
        <nav id="main-menu" class="navbar navbar-default " role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="https://ashokaindia.co.in/"><img src="img/logo.png" width="250" alt="PCA EDU"></a>
                </div>
				
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
	             
              <li ><a href="login.php" class="btn btn-default btn-md top-btn">Center Login</a></li>


 </ul>
                </div>
            </div>
        </nav>
    </header>
  
  <section id="title-head">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title text-center wow fadeInDown">Center Login</h2>
                <p class="text-center wow fadeInDown">Login to franchise management account. </p>
            </div>
        </div>
    </section>


    	<section id="about">
    		<div class="container">
    			<div class="row">
    				<div class="col-md-8 col-md-offset-2 wow fadeIn" data-wow-offset="50" data-wow-delay="0.9s">


	   
                    
                

<div class="panel panel-default reg_form">
  <div class="panel-body">

	 <div class="page-heading">
				  <div class="widget">
  <div class="panel-heading">Login to your Franchise account.</div>
				  </div>
				</div>

						<form action="" class="form-horizontal" role="form" method="post" accept-charset="utf-8">
						    <div class="form-group">
							<label for="inputEmail3" class="col-sm-3 control-label">Email :</label>
							<div class="col-sm-9">
							 <input name="username" class="form-control validate[required,custom[email]]" placeholder="Email" maxlength="150" type="email"  required="required"/>
							 </div>
						  </div>
						  <div class="form-group">
							<label for="inputPassword3" class="col-sm-3 control-label">Password</label>
							<div class="col-sm-9">
							  <input name="password" class="form-control input-sm validate[required,minSize[4],maxSize[15]]" placeholder="Password" type="password"  required="required"/>							</div>
						  </div>
						 <div class="form-group text-center">
								<div class="col-sm-offset-3 col-sm-2">
								<button type="submit" class="btn btn-md btn-primary" name="submit"><span class="glyphicon glyphicon-log-in"></span> Sign In</button>
								</div>
								<?php if($msg == true){  
                                            echo "<p style='color: red;font-weight: bold;text-align: center;'>Oops, Invalid Username or Password. Please try again..</p>";
                                            } ?>
							    </div>
							<div class="form-group">								
								<div class="col-md-12">
									<div class="col-md-6">
										<a href="password.php"><span class="glyphicon glyphicon-cog"></span>&nbsp; Forgot Password</a>
									</div>
								</div>								
							</div>
						</form>				

  </div>
</div>

    				</div>
    			</div>
    		</div>
    	</section>
    	

    <footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-5">
                    <p >Copyright &copy; <span>2022</span> Ashoka India</p>
                </div>
                 <div class="col-sm-3 wow bounceIn">
Powered by: <a href="https://www.microcen.com" title="Website Application Developer" target="_blank">Microcen Web Technology </a>
</div>
<div class="col-sm-3">

                            </div>
                <div class="col-sm-3">
                   
                </div>
            </div>
        </div>
    </footer>	
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/owl.carousel.min.js"></script>
	<script type="text/javascript" src="js/wow.min.js"></script>
	<script type="text/javascript" src="js/mousescroll.js"></script>
	<script type="text/javascript" src="js/main.js"></script>
	<script type="text/javascript" src="js/smoothscroll.js"></script>
	<script type="text/javascript" src="js/jquery.prettyPhoto.js"></script>
	<script type="text/javascript" src="js/jquery.isotope.min.js"></script>
	<script type="text/javascript" src="js/jquery.inview.min.js"></script>	
</body>
</html>