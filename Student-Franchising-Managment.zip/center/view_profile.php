<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
}
include'db.php';
$cid=$_SESSION['username'];         
$sql="SELECT * FROM users where logid='$cid'";
$query = mysqli_query($con, $sql);
$res = mysqli_fetch_array($query);
$uid=$res['uid'];
$sql1="SELECT * FROM franchisee where f_uid='$uid'";
$query1 = mysqli_query($con, $sql1);
$res1 = mysqli_fetch_array($query1);
$id=$_GET['view'];
$sql3="SELECT * FROM stud where uid ='$id'";
$query3 = mysqli_query($con, $sql3);
$res3 = mysqli_fetch_array($query3);
$studid=$res3['uid'];
$sql2="SELECT * FROM course where uid='$studid'";
$query2 = mysqli_query($con, $sql2);
$res2 = mysqli_fetch_array($query2);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Users | Ashoka India	</title>
	<meta name="description" content=""/>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet">
    <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Playball' rel='stylesheet' type='text/css'>
	<link href="/favicon.ico" type="image/x-icon" rel="icon" />
	<link href="/favicon.ico" type="image/x-icon" rel="shortcut icon" />
	<link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
	<link rel="stylesheet" type="text/css" href="css/animate.min.css" />
	<link rel="stylesheet" type="text/css" href="css/owl.transitions.css" />
	<link rel="stylesheet" type="text/css" href="css/prettyPhoto.css" />
	<link rel="stylesheet" type="text/css" href="css/main.css" />
	<link rel="stylesheet" type="text/css" href="css/responsive.css" />
	<script type="text/javascript" src="js/jquery.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
</head>
	<body id="top">
		<!-- start preloader -->
		<div class="preloader">
			<div class="sk-spinner sk-spinner-wave">
     	 		<div class="sk-rect1"></div>
       			<div class="sk-rect2"></div>
       			<div class="sk-rect3"></div>
      	 		<div class="sk-rect4"></div>
      			<div class="sk-rect5"></div>
     		</div>
    	</div>
    	<!-- end preloader -->
		<header id="header">
        <nav id="main-menu" class="navbar navbar-default " role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="https://ashokaindia.co.in/"><img src="img/logo.png" width="250" alt="PCA EDU"></a>
                </div>
				
                <div class="collapse navbar-collapse navbar-right">
    <ul class="nav navbar-nav">
            <li class="dropdown active">
              <a href="javascript:void(0)" class="dropdown-toggle " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="glyphicon glyphicon-user"></i>  <?php echo $res1['f_center'];  ?><span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="account.php" >My Profile</a></li>
                <li><a href="pass_change.php" >Change Password</a></li>
                <li><a href="logout.php" >Log Out!</a></li>
              </ul>
            </li>
    </ul>
    </div>
    </div>
    </nav>
</header>
        
                    



 <!-- start home -->
    	<section id="about">
    		<div class="container">
            <div class="row">
         <div class="col-sm-3 wow fadeInLeft">
         <div class="sidebar-nav">
        <div class="navbar navbar-inverse" role="navigation">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <span class="visible-xs navbar-brand">Sidebar Menu</span>
        </div>
        <div class="navbar-collapse collapse sidebar-navbar-collapse">
          <ul class="nav navbar-nav">
                <li><a href="account.php" >Home</a></li>
                <li><a href="registration.php" >Registrations</a></li>
                <li><a href="account.php" >My Profile</a></li>
                <li><a href="logout.php" >Logout</a></li>
          </ul>
        </div>
      </div>
    </div>
</div>

<div class=" col-md-8 ">
<div class="t-body tb-padding">
<div class="tile">
   <div class="t-header">
<div class="pull-right box-tools">
<a href="registration.php" class="btn btn-primary btn-sm"><span class="glyphicon glyphicon-chevron-left"></span> Back to Dashboard</a></div>
<div class="th-title"><h4>Registration #<?php echo $res2['slno'];?></h4> <small>Registration Details</small>
<hr>
</div>
</div>
<div class="t-body tb-padding">
<div class="row">
<div class="col-md-7">
<div class="table-responsive">
    <table class="table table-hover ">
        <tbody>

        <tr>
            <td>Center Code</td>
            <td>   <?php echo $res2['center_code'];?> 
            </td>
           
        </tr> 

        <tr>
            <td>Franchise Name</td>
            <td>   <?php echo $res2['center'];?>
            </td>
           
        </tr> 


         <tr>
            <td>Student Name.</td>
            <td>   <?php echo $res3['name'];?>
            </td>
           
        </tr> 
        <tr>
            <td>SO/DO/WO</td>
            <td>   <?php echo $res3['fname'];?>
            </td>
           
        </tr>
        <tr>
            <td>Mother Name</td>
            <td>   <?php echo $res3['mname'];?>  
            </td>
           
        </tr>


        
        <!--<tr>
            <td>Parent's Occupation</td>
            <td>   Business  
            </td>
           
        </tr>-->

        <tr>
            <td>Date Of birth</td>
            <td>   <?php echo $res3['dob'];?>  
            </td>
           
        </tr>


        <tr>
            <td>Gender</td>
            <td>   <?php echo $res3['gender'];?>  
            </td>
           
        </tr>

        <!--<tr>
            <td>Marital Status</td>
            <td>   UNMARRIED  
            </td>
           
        </tr>-->
        
        <tr>
            <td>Email</td>
            <td>   <?php echo $res3['mail'];?> 
            </td>
           
        </tr>

 


         <tr>
            <td>Mobile</td>
            <td>   <?php echo $res3['cell'];?>  
            </td>
           
        </tr>


       <!-- <tr>
            <td>Alt. Mobile</td>
            <td>     
            </td>
           
        </tr>-->


        <tr>
            <td>Permanent Address</td>
            <td>   <?php echo $res3['address'];?>, District-<?php echo $res3['district'];?>, Pincode-<?php echo $res3['postal_code'];?> </td>
           
        </tr>


        <!--<tr>
            <td>Correspondence Address</td>
            <td>   Vill-madhepur,distt-madhubani,pin-847408 Madhubani,847408,Bihar            </td>
           
        </tr>


        <tr>
            <td>Candidate Experience</td>
            <td> FRESHER  
            </td>
           
        </tr>  

          <tr>
            <td>Course Type</td>
            <td>   Professional Course  
            </td>
           
        </tr>  
        <tr>
            <td>Plan</td>
            <td>   1  
            </td>
           
        </tr> --> 
 
      <tr>
            <td>Course Name</td>
            <td> <?php echo $res2['course'];?>  
            </td>
           
        </tr>

       <!-- <tr>
            <td>Scholarship type</td>
            <td>   
            </td>
           
        </tr>-->
        
        </tbody>
        </table>
        
        </div>  
    </div> 
          
<div class="col-md-5">

<?php 
                   echo '<p><div class="img-res text-center"><img src="data:image/jpeg;base64,'.base64_encode($res3['photo']).'" alt="" width="200" /></div></p>';
                ?>


<div class="table-responsive">
           <table class="table table-hover table-responsive table-bordered">
 
        <tbody>
        

        <tr>
            <td width="20%">Status</td>
            		<td>	<span class="label label-success"><?php echo $res2['status'];?></span></td>
           
        </tr>
        <tr>
            <td>Pay Status</td>
            <td>     
            </td>
           
        </tr>
        </tbody>
        </table>
        
       </div> 

<h4><strong>File Details</strong></h4>
<div class="table-responsive">
<table class="table table-hover table-responsive table-bordered">
 
<tbody>
        

      <tr>
            <td>File One</td>
                <td colspan= "2">
    <div class="img-responsive "> 


    </div>

</td>
           
        </tr>

        <tr>
            <td>File Two</td>
               <td colspan= "2">
<div class="img-responsive "> 


</div>

</td>
           
        </tr>

        </tbody>
        </table>
       </div> 
</div> 
</div>
</div>
</div>
</div> 
</div>
</div>
</div>
</section>

<footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-5">
                    <p >Copyright &copy; <span>2022</span> Ashoka India</p>
                </div>
                 <div class="col-sm-3 wow bounceIn">
Powered by: <a href="https://www.microcen.com" title="Website Application Developer" target="_blank">Microcen Web Technology </a>
</div>
<div class="col-sm-3">

</div>
<div class="col-sm-3">
                   
</div>
</div>
</div>
</footer>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/owl.carousel.min.js"></script>
	<script type="text/javascript" src="js/wow.min.js"></script>
	<script type="text/javascript" src="js/mousescroll.js"></script>
	<script type="text/javascript" src="js/main.js"></script>
	<script type="text/javascript" src="js/smoothscroll.js"></script>
	<script type="text/javascript" src="js/jquery.prettyPhoto.js"></script>
	<script type="text/javascript" src="js/jquery.isotope.min.js"></script>
	<script type="text/javascript" src="js/jquery.inview.min.js"></script>
</body>
</html>