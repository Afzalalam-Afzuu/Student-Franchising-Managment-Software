<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
}
include'db.php';
$cid=$_SESSION['username'];         
$sql="SELECT * FROM users where logid='$cid'";
$query = mysqli_query($con, $sql);
$res = mysqli_fetch_array($query);
$uid=$res['uid'];
$sql1="SELECT * FROM franchisee where f_uid='$uid'";
$query1 = mysqli_query($con, $sql1);
$res1 = mysqli_fetch_array($query1);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Users | Ashoka India	</title>
	<meta name="description" content=""/>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet">
    <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Playball' rel='stylesheet' type='text/css'>
	<link href="/favicon.ico" type="image/x-icon" rel="icon" />
	<link href="/favicon.ico" type="image/x-icon" rel="shortcut icon" />
	<link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
	<link rel="stylesheet" type="text/css" href="css/animate.min.css" />
	<link rel="stylesheet" type="text/css" href="css/owl.transitions.css" />
	<link rel="stylesheet" type="text/css" href="css/prettyPhoto.css" />
	<link rel="stylesheet" type="text/css" href="css/main.css" />
	<link rel="stylesheet" type="text/css" href="css/responsive.css" />
	<script type="text/javascript" src="js/jquery.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
</head>
	<body id="top">
		<!-- start preloader -->
		<div class="preloader">
			<div class="sk-spinner sk-spinner-wave">
     	 		<div class="sk-rect1"></div>
       			<div class="sk-rect2"></div>
       			<div class="sk-rect3"></div>
      	 		<div class="sk-rect4"></div>
      			<div class="sk-rect5"></div>
     		</div>
    	</div> 
    	<!-- end preloader -->


		<header id="header">
        <nav id="main-menu" class="navbar navbar-default " role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="https://ashokaindia.co.in/"><img src="img/logo.png" width="250" alt="PCA EDU"></a>
                </div>
				
                <div class="collapse navbar-collapse navbar-right">
    <ul class="nav navbar-nav">
            <li class="dropdown active">
              <a href="javascript:void(0)" class="dropdown-toggle " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="glyphicon glyphicon-user"></i>  <?php echo $res1['f_center'];  ?><span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="account.php" >My Profile</a></li>
                <li><a href="pass_change.php" >Change Password</a></li>
                <li><a href="logout.php" >Log Out!</a></li>
              </ul>
            </li>
    </ul>
    </div>
    </div>
    </nav>
</header>
 
<section id="about">
<div class="container">
<div class="row">
 <div class="col-sm-3 wow fadeInLeft">
 <div class="sidebar-nav">
      <div class="navbar navbar-inverse" role="navigation">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <span class="visible-xs navbar-brand">Sidebar Menu</span>
        </div>
        <div class="navbar-collapse collapse sidebar-navbar-collapse">
          <ul class="nav navbar-nav">
                <li><a href="account.php" >Home</a></li>
                <li><a href="registration.php" >Registrations</a></li>
                <li><a href="account.php" >My Profile</a></li>
                <li><a href="logout.php" >Logout</a></li>
          </ul>
        </div>
      </div>
    </div>
</div>
<div class=" col-md-8 ">
<a href="new_reg.php" class="btn btn-success btn-sm"><span class="glyphicon glyphicon-plus"></span> Add New Registration</a>
<hr>
<div class="t-body tb-padding">
   <table id="data-table" class="table table-hover table-striped ">
      <thead>
         <tr>
            <th><a href="javascript:void(0)" class="desc">Reg. # </a></th>
            <th><a href="javascript:void(0)">Name </a></th>
            <th><a href="javascript:void(0)">Mobile</a></th>
            <th><a href="javascript:void(0)">District</a></th>
            <th><a href="javascript:void(0)">Course</a></th>
            <th><a href="javascript:void(0)">Status</a></th>
            <th>Action</th>
         </tr>
      </thead>
     <tbody>
                    <?php
                              $sql3="SELECT * FROM stud where owner_id ='$uid'";
                              $query3 = mysqli_query($con, $sql3);
                              while ($res3 = mysqli_fetch_array($query3)) {
                                $uid1=$res3['uid'];
                                $sql4="SELECT * FROM course where uid='$uid1'";
                                $query4 = mysqli_query($con, $sql4);
                                $res4 = mysqli_fetch_array($query4);
                        ?>
        <tr>
            <td><?php echo $res4['reg_no'];  ?></td>
            <td><?php echo $res3['name'];  ?></td>
            <td><?php echo $res3['cell'];  ?></td>
            <td><?php echo $res3['district'];?></td>
            <td><?php echo $res4['course'];?></td>
            <td><span class="label label-success"><?php echo $res4['status'];?></span></td> 
            <td ><a href="view_profile.php?view=<?php echo $uid1 ?>" class="btn btn-info btn-sm"><span class="glyphicon glyphicon-eye-open"></span></a></td>
         </tr>
         <?php } ?>
                  
    </tbody>
   </table>
   


    <div class="row">
        <div class="col-md-7 text-right">
            <ul class="pagination pagination-sm">
                <li class="disabled"><a>&larr; Previous</a></li><li class="disabled"><a>&rarr; Next</a></li>                </ul>
            </div>
            <div class="col-md-5 text-left pad">
              <p>  <small>Showing 1 to 11 of 11 entries</small></p>
            </div>
     
    </div>
    </div> 
</div> 
</div>
</div>
</div>
</section>

<footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-5">
                    <p >Copyright &copy; <span>2022</span> Ashoka India</p>
                </div>
                 <div class="col-sm-3 wow bounceIn">
Powered by: <a href="https://www.microcen.com" title="Website Application Developer" target="_blank">Microcen Web Technology </a>
</div>
<div class="col-sm-3">

                            </div>
                <div class="col-sm-3">
                   
                </div>
            </div>
        </div>
    </footer>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/owl.carousel.min.js"></script>
	<script type="text/javascript" src="js/wow.min.js"></script>
	<script type="text/javascript" src="js/mousescroll.js"></script>
	<script type="text/javascript" src="js/main.js"></script>
	<script type="text/javascript" src="js/smoothscroll.js"></script>
	<script type="text/javascript" src="js/jquery.prettyPhoto.js"></script>
	<script type="text/javascript" src="js/jquery.isotope.min.js"></script>
	<script type="text/javascript" src="js/jquery.inview.min.js"></script>
</body>
</html>