<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
}
include'db.php';
$cid=$_SESSION['username'];         
$sql="SELECT * FROM users where logid='$cid'";
$query = mysqli_query($con, $sql);
$res = mysqli_fetch_array($query);
$uid=$res['uid'];
$sql1="SELECT * FROM franchisee where f_uid='$uid'";
$query1 = mysqli_query($con, $sql1);
$res1 = mysqli_fetch_array($query1);
?>

<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
	<title>Users | Ashoka India	</title>
	<meta name="description" content=""/>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Playball" rel="stylesheet" type="text/css">
    <link href="https://app.pcaedu.in/favicon.ico" type="image/x-icon" rel="icon" />
	<link href="https://app.pcaedu.in/favicon.ico" type="image/x-icon" rel="shortcut icon" />
	<link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
	<link rel="stylesheet" type="text/css" href="css/animate.min.css" />
	<link rel="stylesheet" type="text/css" href="css/owl.transitions.css" />
	<link rel="stylesheet" type="text/css" href="css/prettyPhoto.css" />
	<link rel="stylesheet" type="text/css" href="css/main.css" />
	<link rel="stylesheet" type="text/css" href="css/responsive.css" />
	<script type="text/javascript" src="js/jquery.js"></script>
    <link rel="stylesheet" href="css/font-awesome.min.css">
</head>
	
	<body id="top">
    

		<!-- start preloader -->
		<div class="preloader">
			<div class="sk-spinner sk-spinner-wave">
     	 		<div class="sk-rect1"></div>
       			<div class="sk-rect2"></div>
       			<div class="sk-rect3"></div>
      	 		<div class="sk-rect4"></div>
      			<div class="sk-rect5"></div>
     		</div>
    	</div>
    	<!-- end preloader -->
		<header id="header">
        <nav id="main-menu" class="navbar navbar-default " role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="https://ashokaindia.co.in/"><img src="img/logo.png" width="250" alt="PCA EDU"></a>
                </div>
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
            <li class="dropdown active">
              <a href="javascript:void(0)" class="dropdown-toggle " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="glyphicon glyphicon-user"></i>  <?php echo $res1['f_center'];  ?> <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="account.php" >My Profile</a></li>
                <li><a href="pass_change.php" >Change Password</a></li>

                <li><a href="logout.php">Log Out!</a></li>
              </ul>
            </li>
            </ul>
            </div>
            </div>
        </nav>
    </header>
<!-- start home -->
<section id="about">
<div class="container">
<div class="row">
 <div class="col-sm-3 wow fadeInLeft">
 <div class="sidebar-nav">
      <div class="navbar navbar-inverse" role="navigation">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <span class="visible-xs navbar-brand">Sidebar Menu</span>
        </div>
        <div class="navbar-collapse collapse sidebar-navbar-collapse">
          <ul class="nav navbar-nav">
                <li><a href="account.php" >Home</a></li>
                <li><a href="registration.php" >Registrations</a></li>
                <li><a href="account.php" >My Profile</a></li>
                <li><a href="logout.php" >Logout</a></li>
          </ul>
        </div>
      </div>
    </div>
</div>




<div class=" col-md-8 ">

<div class="t-body tb-padding">

<div class="table-responsive">

           <table class="table  ">
 
<thead>
<tr>
            <td colspan="2"> <span class="text-center wow fadeIn" style="color:#FFF;"><strong>Franchise Profile </strong></span>
</td>
            
           
        </tr> 
</thead>

        <tbody>

        <tr>
            <td>Franchise Center Code </td>
            <td>  <strong> <?php echo $res1['f_code'];  ?>  </strong>            </td>
           
        </tr> 


        
         <tr>
            <td>Name.</td>
            <td>  <strong> <?php echo $res1['f_center'];  ?>  </strong>
            </td>
           
        </tr> 


        <tr>
            <td>Authorised Person </td>
            <td>   <?php echo $res['name'];  ?> 
            </td>
           
        </tr> 


         <tr>
            <td>Organization Name</td>
            <td>   <?php echo $res1['f_center'];  ?>  
            </td>
           
        </tr>

        <tr>
            <td>Mobile</td>
            <td>   <?php echo $res['cell'];  ?> 
            </td>
           
        </tr>

        
 


        
        <tr>
            <td>Email</td>
            <td> <strong>  <?php echo $res['mail'];  ?>  </strong>
            </td>
           
        </tr>


         <tr>
            <td>Address</td>
            <td>    <?php echo $res1['f_address'];  ?> 
            </td>
           
        </tr>


        <tr>
            <td>Profile Date</td>
            <td><?php echo $res1['f_rdate'];  ?></td> 
            
        </tr>

        <tr>
            <td>Profile Updated </td>
            <td><?php echo $res1['f_rdate'];  ?></td>
            
        </tr>

<tr class="hidden-print">
<td></td> 
<td><a href="pass_change.php"  class="btn btn-danger">  <i class="glyphicon glyphicon-refresh"></i> Change Password</a></td>
</tr>
</tbody>
</table>
</div> 
</div> 
</div>
</div>
</div>
</section>
 <footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-5">
                    <p >Copyright &copy; <span>2022</span> Ashoka India</p>
                </div>
                 <div class="col-sm-3 wow bounceIn">
                    Powered by: <a href="https://www.microcen.com" title="Website Application Developer" target="_blank">Microcen Web Technology </a>
                 </div>
            </div>
        </div>
    </footer>	

	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/owl.carousel.min.js"></script>
	<script type="text/javascript" src="js/wow.min.js"></script>
	<script type="text/javascript" src="js/mousescroll.js"></script>
	<script type="text/javascript" src="js/main.js"></script>
	<script type="text/javascript" src="js/smoothscroll.js"></script>
	<script type="text/javascript" src="js/jquery.prettyPhoto.js"></script>
	<script type="text/javascript" src="js/jquery.isotope.min.js"></script>
	<script type="text/javascript" src="js/jquery.inview.min.js"></script>	
</body>
</html>