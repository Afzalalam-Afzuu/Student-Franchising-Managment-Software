<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
}
include'db.php';
$cid=$_SESSION['username'];         
$sql="SELECT * FROM users where logid='$cid'";
$query = mysqli_query($con, $sql);
$res = mysqli_fetch_array($query);
$uid=$res['uid'];
$uid1=$res['u_no'];
$sql1="SELECT * FROM franchisee where f_uid='$uid'";
$query1 = mysqli_query($con, $sql1);
$res1 = mysqli_fetch_array($query1);
?>
<!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
	<title>Users | Ashoka India	</title>
	<meta name="description" content=""/>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Playball" rel="stylesheet" type="text/css">
    <link href="https://app.pcaedu.in/favicon.ico" type="image/x-icon" rel="icon" />
	<link href="https://app.pcaedu.in/favicon.ico" type="image/x-icon" rel="shortcut icon" />
	<link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
	<link rel="stylesheet" type="text/css" href="css/animate.min.css" />
	<link rel="stylesheet" type="text/css" href="css/owl.transitions.css" />
	<link rel="stylesheet" type="text/css" href="css/prettyPhoto.css" />
	<link rel="stylesheet" type="text/css" href="css/main.css" />
	<link rel="stylesheet" type="text/css" href="css/responsive.css" />
	<script type="text/javascript" src="js/jquery.js"></script>
    <link rel="stylesheet" href="css/font-awesome.min.css">
</head>
	<body id="top">
    

		<!-- start preloader -->
		<div class="preloader">
			<div class="sk-spinner sk-spinner-wave">
     	 		<div class="sk-rect1"></div>
       			<div class="sk-rect2"></div>
       			<div class="sk-rect3"></div>
      	 		<div class="sk-rect4"></div>
      			<div class="sk-rect5"></div>
     		</div>
    	</div>
    	<!-- end preloader -->

	<header id="header">
        <nav id="main-menu" class="navbar navbar-default " role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="https://ashokaindia.co.in/"><img src="img/logo.png" width="250" alt="PCA EDU"></a>
                </div>
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
            <li class="dropdown active">
              <a href="javascript:void(0)" class="dropdown-toggle " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="glyphicon glyphicon-user"></i>  <?php echo $res1['f_center'];  ?> <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="account.php" >My Profile</a></li>
                <li><a href="pass_change.php" >Change Password</a></li>

                <li><a href="logout.php">Log Out!</a></li>
              </ul>
            </li>
            </ul>
            </div>
            </div>
        </nav>
    </header>



 <!-- start home -->
<section id="about">
<div class="container">
<div class="row">
<div class="col-sm-3 wow fadeInLeft">
 <div class="sidebar-nav">
      <div class="navbar navbar-inverse" role="navigation">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <span class="visible-xs navbar-brand">Sidebar Menu</span>
        </div>
        <div class="navbar-collapse collapse sidebar-navbar-collapse">
          <ul class="nav navbar-nav">
                <li><a href="account.php" >Home</a></li>
                <li><a href="registration.php" >Registrations</a></li>
                <li><a href="account.php" >My Profile</a></li>
                <li><a href="logout.php" >Logout</a></li>
          </ul>
        </div>
      </div>
    </div>
</div>
<div class=" col-md-8 ">
  <div class="panel panel-default">
            <div class="panel-heading">
			<div class="widget">
				<h4 class="widget-title">Change <span>Password</span></h4>
			</div>
		</div>            
                <div class="panel-body">
                <form action="" class="form-horizontal" method="post" accept-charset="utf-8">
                        
                    <div class="form-group">
                        <label for="group_name" class="col-sm-3 control-label">Old Password</label>
                        <input type="hidden" name="current" value="<?php echo $res['logpwd'];?>"/>
                        
                        <div class="col-sm-9">
                           <input name="currentPassword" id="oldPassword" value="" class="form-control input-sm validate[required,minSize[4],maxSize[15]]" placeholder="Old Password" type="password"/>
                          </div>
                    </div>
                    <div class="form-group">
                        <label for="group_name" class="col-sm-3 control-label">Password</label>
                        <div class="col-sm-9">
                        <input name="newPassword" id="password" value="" class="form-control input-sm validate[required,minSize[4],maxSize[15]]" placeholder="Password" type="password" required="required">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="group_name" class="col-sm-3 control-label">Confirm Password</label>
                        <div class="col-sm-9">
                            <input name="confirmPassword" value="" class="form-control input-sm validate[required,minSize[4],maxSize[15],equals[password]]" placeholder="Confirm Password" type="password" id="UserConPassword" onkeyup="checkPass(); return false;">

                         <span id="confirmMessage" class="confirmMessage"></span>

                        </div>
                    </div>
                    <div class="form-group text-left">
                        <div class="col-sm-offset-3 col-sm-10">
                            <button type="submit" name="submit" id="submit" class="btn btn-success"><span class="glyphicon glyphicon-refresh"></span> Update</button>                            
                        </div>
                    </div>
                </form>
                
                
											    <?php
                                        if (isset($_POST['submit'])) {
                                            $current= $_POST['current'];
                                            $currentPassword = $_POST['currentPassword'];
                                            $newPassword = $_POST['newPassword'];
                                            $confirmPassword = $_POST['confirmPassword'];
                                            
                                            
                                            
                                            if ($currentPassword != null && $newPassword != null  && $confirmPassword != null) {
                                                
                                                
                                                if ($current==$currentPassword && $newPassword==$confirmPassword) { 
                                                    $insert_cat = mysqli_query($con,"UPDATE users set logpwd='$newPassword' WHERE u_no='$uid1'");
                                                    if ($insert_cat) {

                                                        echo '<div class="card-footer text-center">
                                  <p style="color:green">Password has been Updated </p>
                                </div>';
                                
                                                    } else {
                                                        echo '<div class="card-footer text-center">
                                  <p style="color:red">Failed to Password Update!</p>
                                </div>';
                                                        echo("Error description: " . mysqli_error($connect));
                                                    }
                                                } else {
                                                    echo '<div class="card-footer text-center">
                                  <p style="color:red">Please Fill Valid Your Old Password!</p>
                                </div>';
                                                }
                                            } else {
                                                echo '<div class="card-footer text-center">
                                  <p style="color:red">Please Fill All Data</p>
                                </div>';
                                            }
                                        }
                                        ?>

        
                
                
                </div>
            </div>





        </div> <!-- /.col -->
          


<script type="text/javascript">

function checkPass()
{
    //Store the password field objects into variables ...
    var pass1 = document.getElementById('password');
    var oldpass = document.getElementById('oldPassword');

    var pass2 = document.getElementById('UserConPassword');
    //Store the Confimation Message Object ...
    var message = document.getElementById('confirmMessage');
    //Set the colors we will be using ...
    var goodColor = "#66cc66";
    var badColor = "#ff6666";
    //Compare the values in the password field 
    //and the confirmation field
    if(pass1.value == pass2.value){
        //The passwords match. 
        //Set the color to the good color and inform
        //the user that they have entered the correct password 
        pass2.style.backgroundColor = goodColor;
        message.style.color = goodColor;
        message.innerHTML = "Passwords Match!"
           document.getElementById('submit').removeAttribute("disabled");

    }else{
        //The passwords do not match.
        //Set the color to the bad color and
        //notify the user.
        pass2.style.backgroundColor = badColor;
        message.style.color = badColor;
        message.innerHTML = "Passwords Do Not Match!"
      document.getElementById('submit').setAttribute("disabled", "disabled");

    }
}  

</script>
</div><!-- end col-->
</div>
</div>
</section>
<!-- end home -->
<footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-5">
                    <p >Copyright &copy; <span>2022</span> Ashoka India</p>
                </div>
                 <div class="col-sm-3 wow bounceIn">
                    Powered by: <a href="https://www.microcen.com" title="Website Application Developer" target="_blank">Microcen Web Technology </a>
                 </div>
            </div>
        </div>
    </footer>	
<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/owl.carousel.min.js"></script>
	<script type="text/javascript" src="js/wow.min.js"></script>
	<script type="text/javascript" src="js/mousescroll.js"></script>
	<script type="text/javascript" src="js/main.js"></script>
	<script type="text/javascript" src="js/smoothscroll.js"></script>
	<script type="text/javascript" src="js/jquery.prettyPhoto.js"></script>
	<script type="text/javascript" src="js/jquery.isotope.min.js"></script>
	<script type="text/javascript" src="js/jquery.inview.min.js"></script>	
</body>
</html>