
<!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
	<title>Users | Ashoka India	</title>
	<meta name="description" content=""/>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Playball" rel="stylesheet" type="text/css">
    <link href="https://app.pcaedu.in/favicon.ico" type="image/x-icon" rel="icon" />
	<link href="https://app.pcaedu.in/favicon.ico" type="image/x-icon" rel="shortcut icon" />
	<link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
	<link rel="stylesheet" type="text/css" href="css/animate.min.css" />
	<link rel="stylesheet" type="text/css" href="css/owl.transitions.css" />
	<link rel="stylesheet" type="text/css" href="css/prettyPhoto.css" />
	<link rel="stylesheet" type="text/css" href="css/main.css" />
	<link rel="stylesheet" type="text/css" href="css/responsive.css" />
	<script type="text/javascript" src="js/jquery.js"></script>
    <link rel="stylesheet" href="css/font-awesome.min.css">
</head>
	<body id="top">
    

		<!-- start preloader -->
		<div class="preloader">
			<div class="sk-spinner sk-spinner-wave">
     	 		<div class="sk-rect1"></div>
       			<div class="sk-rect2"></div>
       			<div class="sk-rect3"></div>
      	 		<div class="sk-rect4"></div>
      			<div class="sk-rect5"></div>
     		</div>
    	</div>
    	
	<header id="header">
        <nav id="main-menu" class="navbar navbar-default " role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="/"><img src="img/logo.png" width="250" alt="PCA EDU"></a>
                </div>
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                <li ><a href="login.php" class="btn btn-default btn-md top-btn">Center Login</a></li>

                </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->
    </header><!--/header-->
    
<section id="content-title">
<div class="container">
<div class="row">
<div class="col-md-12 wow fadeInLeft" data-wow-delay="0.6s">
<h2 class="widget-title text-center">Reset your<span> Account Password</span></h2>
</div>
</div>
</div>
</section>
<section id="content">
<div class="container">
<div class="row">
<div class="col-md-6 col-md-offset-3 wow fadeInRight" data-wow-delay="0.6s">
<div class="panel panel-default loginbox">
<div class="panel-body">
<div class="page-heading">
<div class="widget">
 <div class="panel-heading">Contact ASHOKA INSTITUTE OF COMPUTER ACADEMY support team via email/ mobile to reset your password for help <a href="https://ashokaindia.co.in/contact_us.php" aria-current="page">Contact us.</a> </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>

<script type="text/javascript">
    $(document).ready(function(){
    $('#post_req').validationEngine();
    
});
</script>	
<footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-5">
                    <p >Copyright &copy; <span>2022</span> Ashoka India</p>
                </div>
                 <div class="col-sm-3 wow bounceIn">
                    Powered by: <a href="https://www.microcen.com" title="Website Application Developer" target="_blank">Microcen Web Technology </a>
                 </div>
            </div>
        </div>
    </footer>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/owl.carousel.min.js"></script>
	<script type="text/javascript" src="js/wow.min.js"></script>
	<script type="text/javascript" src="js/mousescroll.js"></script>
	<script type="text/javascript" src="js/main.js"></script>
	<script type="text/javascript" src="js/smoothscroll.js"></script>
	<script type="text/javascript" src="js/jquery.prettyPhoto.js"></script>
	<script type="text/javascript" src="js/jquery.isotope.min.js"></script>
	<script type="text/javascript" src="js/jquery.inview.min.js"></script>
</body>
</html>