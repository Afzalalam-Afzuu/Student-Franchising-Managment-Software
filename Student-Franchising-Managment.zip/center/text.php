<?php
$first2="00";
    $empmobile="92";
    $second2=substr($empmobile,-2);
    $empdob="1992";
                                    $secondup2=strtoupper($second2);
                                    $third2=substr($empdob,-2);
                                    $thirdup2=strtoupper($third2);
                                    $empid=$first2.$secondup2.$thirdup2;
                                    echo $empid;

?>