<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
}
include'db.php';
$cid=$_SESSION['username'];         
$sql="SELECT * FROM users where logid='$cid'";
$query = mysqli_query($con, $sql);
$res = mysqli_fetch_array($query);
$uid=$res['uid'];
$sql1="SELECT * FROM franchisee where f_uid='$uid'";
$query1 = mysqli_query($con, $sql1);
$res1 = mysqli_fetch_array($query1);
 
?>
<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
	<title>Users | Ashoka India	</title>
	<meta name="description" content=""/>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet">
    <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Playball' rel='stylesheet' type='text/css'>
	<link href="/favicon.ico" type="image/x-icon" rel="icon" />
	<link href="/favicon.ico" type="image/x-icon" rel="shortcut icon" />
	<link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
	<link rel="stylesheet" type="text/css" href="css/animate.min.css" />
	<link rel="stylesheet" type="text/css" href="css/owl.transitions.css" />
	<link rel="stylesheet" type="text/css" href="css/prettyPhoto.css" />
	<link rel="stylesheet" type="text/css" href="css/main.css" />
	<link rel="stylesheet" type="text/css" href="css/responsive.css" />
	<script type="text/javascript" src="js/jquery.js"></script>
	
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

</head>
	<body id="top">
		<!-- start preloader -->
		<div class="preloader">
			<div class="sk-spinner sk-spinner-wave">
     	 		<div class="sk-rect1"></div>
       			<div class="sk-rect2"></div>
       			<div class="sk-rect3"></div>
      	 		<div class="sk-rect4"></div>
      			<div class="sk-rect5"></div>
     		</div>
    	</div>
    	<!-- end preloader -->
		<header id="header">
        <nav id="main-menu" class="navbar navbar-default " role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="https://ashokaindia.co.in/"><img src="img/logo.png" width="250" alt="PCA EDU"></a>
                </div>
				
<div class="collapse navbar-collapse navbar-right">
<ul class="nav navbar-nav">
<li class="dropdown active">
              <a href="javascript:void(0)" class="dropdown-toggle " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="glyphicon glyphicon-user"></i>  <?php echo $res1['f_center'];  ?> <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="account.php" >My Profile</a></li>
                <li><a href="pass_change.php" >Change Password</a></li>
                <li><a href="logout.php)" >Log Out!</a></li>
              </ul>
</li>
 </ul>
</div>
</div>
</nav>
</header>
 <!-- start home -->
<section id="about">
<div class="container">
<div class="row">
 <div class="col-sm-3 wow fadeInLeft">
 <div class="sidebar-nav">
      <div class="navbar navbar-inverse" role="navigation">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <span class="visible-xs navbar-brand">Sidebar Menu</span>
        </div>
        <div class="navbar-collapse collapse sidebar-navbar-collapse">
          <ul class="nav navbar-nav">
                <li><a href="account.php" >Home</a></li>
                <li><a href="registration.php" >Registrations</a></li>
                <li><a href="account.php" >My Profile</a></li>
                <li><a href="logout.php" >Logout</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </div>
</div>
<div class=" col-md-8 ">
<div class="panel panel-default reg_form">
  <div class="panel-body">

	 <div class="page-heading">
		<div class="widget">
        <div class="panel-heading">New Student <strong>Registration</strong>.</div>
	    </div>
	</div>
 <form action="" controller="Registrations" name="post_req" id="post_req" class="form-horizontal" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div style="display:none;">
<input type="hidden" name="_method" value="POST"/>
</div>
<div class="form-group clearfix" >
<label for="group_name" class="col-sm-3 control-label"><small>Center Code/ Name <span class="text-danger"> *</span> </span></small></label>
<div class="col-sm-8"><?php echo $res1['f_code'];  ?> <br> <?php echo $res1['f_center'];  ?></div>
</div>
<div class="form-group clearfix" >
<label for="group_name" class="col-sm-3 control-label"><small> Name<span class="text-danger"> *</span></small></label>
<div class="col-sm-4">
<input name="first_name" class="form-control   validate[required]" placeholder="First Name" maxlength="100" type="text" id="RegistrationName" required="required"/>
</div>
<div class="col-sm-4">
<input name="last_name" class="form-control   validate[required]" placeholder="Last Name" maxlength="200" type="text" id="RegistrationLastName"/> 
</div>
</div>
 <div class="form-group clearfix" >
<label for="group_name" class="col-sm-3 control-label"><small>SO/WO/DO.<span class="text-danger">*</span></small></label>
<div class="col-sm-8">
<input name="father_name" class="form-control   validate[required]" placeholder="Enter SO/WO/DO." maxlength="200" type="text" id="RegistrationRelation" required="required"/>
</div>
</div>
 <div class="form-group clearfix" >
<label for="group_name" class="col-sm-3 control-label"><small>Mother Name<span class="text-danger">*</span></small></label>
<div class="col-sm-8">
<input name="mother_name" class="form-control   validate[required]" placeholder="Mother Name" maxlength="200" type="text" id="RegistrationMotherName" required="required"/>
</div>
</div>
<div class="form-group clearfix" >
<label for="group_name" class="col-sm-3 control-label"><small>Registration Number<span class="text-danger"> *</span></small></label>
<div class="col-sm-8">
<input name="regnum" class="form-control   validate[required]" placeholder="Registration Number" maxlength="200" type="text"/>
</div>
</div>
<div class="form-group clearfix" >
<label for="group_name" class="col-sm-3 control-label"><small>Email ID<span class="text-danger"> *</span></small></label>
<div class="col-sm-8">
<input name="email" class="form-control   validate[required]" placeholder="Enter Your Email ID." maxlength="100" type="email" id="RegistrationEmail" required="required"/>
</div>
</div>
<div class="form-group clearfix" >
<label for="group_name" class="col-sm-3 control-label"><small> Mobile<span class="text-danger"> *</span></small></label>
<div class="col-sm-4">
<input name="mobile" class="form-control   validate[required]" placeholder="Enter Mobile" maxlength="15" type="text" id="RegistrationMobile" required="required"/>
</div>
<div class="col-sm-4">
<input name="alt_mobile" class="form-control   validate[required]" placeholder="Alt. Mobile" maxlength="15" type="text" id="RegistrationAltcontact"/>
</div>
</div>
 <div class="form-group clearfix" >
<label for="group_name" class="col-sm-3 control-label"><small>Gender<span class="text-danger"> *</span></small></label>
<div class="col-sm-4">
 <select name="gender" class="form-control input-sm" id="RegistrationGender" required="required">
<option value="" selected disabled>Select Gender</option>
<option value="MALE">MALE</option>
<option value="FEMALE">FEMALE</option>
</select>   
</div>
<div class="col-sm-4">
<select name="marital_status" class="form-control input-sm" id="RegistrationMaritalStatus" required="required">
<option value="" selected disabled>Select Marital Status</option>
<option value="MARRIED">MARRIED</option>
<option value="UNMARRIED">UNMARRIED</option>
</select>                        
</div>
</div>
<div class="form-group clearfix" >
<label for="group_name" class="col-sm-3 control-label"><small>Date Of Birth<span class="text-danger"> *</span></small></label>
<div class="col-sm-8">
<input name="dob" class="form-control  validate[required]" placeholder="Enter Date of Birth eg. DD/MM/YYYY" maxlength="100" type="text" id="RegistrationDob" required="required"/>
</div>
</div>
<div class="form-group clearfix" >
<label for="group_name" class="col-sm-3 control-label"><small>Correspondence Address<span class="text-danger"> *</span></small></label>
<div class="col-sm-8">
<textarea name="corres_address" class="form-control  validate[required]" placeholder="Enter your permanent Address" id="RegistrationCAddress" required="required"></textarea>                      
</div>
</div>
<div class="form-group " >
<label for="group_name" class="col-sm-3 control-label"><small>State </small></label>
<div class="col-sm-8">
<select name="corres_state" class="form-control select2" name="RegistrationCState" id="RegistrationCState" required="required">
<option value="" selected disabled>Select State</option>
                        <?php
                        $result = mysqli_query($con,"SELECT * FROM place WHERE data_type='STATE'");
                        while($row = mysqli_fetch_array($result)) {
                        ?>
                        <option value="<?php echo $row['state'];?>"><?php echo $row["state"];?></option>
                        <?php
                        }
                        ?>
                        
</select>
</div>
</div>
<div class="form-group " >
<label for="group_name" class="col-sm-3 control-label"><small>District</small></label>
<div class="col-sm-8">
<select name="corres_dist" class="form-control select2" id="state-dropdown" required="required">
<option value="" selected disabled>Select State First</option>
</select>
<script>
$(document).ready(function() {
   
    $('#RegistrationCState').on('change', function() {
            var state_id = this.value;
            $.ajax({
                url: "cities-by-state.php",
                type: "POST",
                data: {
                    state_id: state_id
                },
                cache: false,
                success: function(result){
                    $("#state-dropdown").html(result);
                }
            });
        
        
    });
});
</script>
</div>
</div>
<div class="form-group clearfix" >
<label for="group_name" class="col-sm-3 control-label"><small>Pin Code<span class="text-danger"> *</span></small></label>
<div class="col-sm-8">
<input name="corres_pin" class="form-control  validate[required]" placeholder="Enter Pin" type="number" id="RegistrationCPin" required="required"/>                        
</div>
</div>
<div class="form-group clearfix" >
<label for="group_name" class="col-sm-3 control-label"><small>Country<span class="text-danger"> *</span></small></label>
<div class="col-sm-8">
<select name="corres_country" class="form-control " id="RegistrationCountry">
<option value="INDIA" selected="selected">INDIA</option>
</select>   
</div>
</div>
<div class="form-group clearfix" >
 <label for="group_name" class="col-sm-4 control-label"></label>
<div class="col-sm-6">
 <label><input type="checkbox" id="add_copy" value="yes" onchange="cpAddress(this)">My Permanent Address is Same as Above </label> 

</div>
</div> 
<div class="form-group clearfix" >
<label for="group_name" class="col-sm-3 control-label"><small>Permanent Address<span class="text-danger"> *</span></small></label>
<div class="col-sm-8">
<textarea name="perm_address" class="form-control  validate[required]" placeholder="Enter your permanent Address" id="RegistrationAddress" required="required"></textarea>   
</div>
</div>
<div class="form-group " >
<label for="group_name" class="col-sm-3 control-label"><small>State</small></label>
<div class="col-sm-8">
<select name="perm_state" class="form-control select3" id="RegistrationCState1" required="required">
<option value="">Select State</option>
                    <?php
                        $result = mysqli_query($con,"SELECT * FROM place WHERE data_type='STATE'");
                        while($row = mysqli_fetch_array($result)) {
                        ?>
                        <option value="<?php echo $row['state'];?>"><?php echo $row["state"];?></option>
                        <?php
                        }
                        ?>
</select>

</div>
</div>
<div class="form-group " >
<label for="group_name" class="col-sm-3 control-label"><small>District</small></label>
<div class="col-sm-8">
<select name="perm_dist" class="form-control select2" id="state-dropdown1" required="required">
<option value="">Select State First</option>
</select>
<script>
$(document).ready(function() {
   
    $('#RegistrationCState1').on('change', function() {
            var state_id1 = this.value;
            $.ajax({
                url: "cities-by-state1.php",
                type: "POST",
                data: {
                    state_id1: state_id1
                },
                cache: false,
                success: function(result){
                    $("#state-dropdown1").html(result);
                }
            });
        
        
    });
});
</script>
</div>
</div>
<div class="form-group clearfix" >
<label for="group_name" class="col-sm-3 control-label"><small>Pin Code<span class="text-danger"> *</span></small></label>
<div class="col-sm-8">
<input name="perm_pin" class="form-control  validate[required]" placeholder="Enter Pin" type="text" id="RegistrationPin" required="required"/>                        
</div>
</div>
<div class="form-group clearfix" >
<label for="group_name" class="col-sm-3 control-label"><small>Country<span class="text-danger"> *</span></small></label>
<div class="col-sm-8">
<select name="perm_country" class="form-control " id="RegistrationCountry">
<option value="INDIA" selected="selected">INDIA</option>
</select>   
</div>
</div>
<script type="text/javascript">
function cpAddress(){
      document.getElementById("RegistrationAddress").value =document.getElementById("RegistrationCAddress").value;
      document.getElementById("RegistrationPin").value =document.getElementById("RegistrationCPin").value ;
      document.getElementById("RegistrationCountry").value =document.getElementById("RegistrationCountry").value;
}
</script>
<div class="form-group">
<label for="group_name" class="col-sm-3 control-label"><small>CANDIDATE EXP<span class="text-danger"> *</span></small></label>
<div class="col-sm-8">
<select name="experiance" class="form-control input-sm" id="RegistrationCExp" required="required">
<option value="">Select Candidate EXPERIENCE</option>
<option value="STUDENT">STUDENT</option>
<option value="SCHOOL DROP">SCHOOL DROP</option>
<option value="FRESHER">FRESHER</option>
<option value="SELF EMPLOYED">SELF EMPLOYED</option>
<option value="PRIVATE EMPLOYED">PRIVATE EMPLOYED</option>
<option value="GOVT EMPLOYED">GOVT EMPLOYED</option>
</select> 
</div>
</div>
<div class="form-group">
<label for="group_name" class="col-sm-3 control-label"><small>Course Selection<span class="text-danger"> *</span></small></label>
<div class="col-sm-8">
<select name="course_name" class="form-control select2" id="RegistrationCourse" required="required">
<option value="" selected disabled>Select Course</option>
<option value="DIPLOMA IN COMPUTER APPLICATION">DIPLOMA IN COMPUTER APPLICATION</option>
<option value="ADVANCE DIPLOMA IN COMPUTER APPLICATION">ADVANCE DIPLOMA IN COMPUTER APPLICATION</option>
<option value="COMPUTER TEACHER TRAINING COURSE">COMPUTER TEACHER TRAINING COURSE</option>
<option value="CCA">CCA</option>
<option value="DCA">DCA</option>
<option value="CFA">CFA</option>
<option value="DDTP">DDTP</option>
<option value="ADHN">ADHN</option>
<option value="ADFA">ADFA</option>
<option value="DCP">DCP</option>
<option value="DOA">DOA</option>
<option value="DHT">DHT</option>
<option value="DHN">DHN</option>
<option value="ADIT">ADIT</option>
<option value="10">ADCA</option>
<option value="ADCA">ADCP</option>
<option value="DCTT">DCTT</option>
<option value="SEF">SEF</option>
<option value="TYPING CERTIFICATE">TYPING CERTIFICATE</option>
<option value="DFA">DFA</option>
<option value="CTTC">CTTC</option>
<option value="19">Photoshop</option>
<option value="Photoshop">DCA-T</option>
<option value="ADCAP">ADCAP</option>
<option value="AUTO CAD">AUTO CAD</option>
<option value="ATE 9">ATE 9</option>
<option value="ABCD">ABCD</option>
<option value="PGDCA">PGDCA</option>
<option value="DEO">DEO</option>
<option value="DDEO">DDEO</option>
<option value="DMM">DMM</option>
<option value="BP">BP</option>
<option value="HDIT">HDIT</option>
<option value="CCEC">CCEC</option>
<option value="DEC">DEC</option>
<option value="ADEC">ADEC</option>
<option value="DC">DC</option>
<option value="C++">C++</option>
<option value="DCADTP">DCADTP</option>
<option value="DDM">DDM</option>
</select>                        
</div>
</div>
<div class="form-group " >
<label for="group_name" class="col-sm-3 control-label"><small>Plan</small></label>
<div class="col-sm-7">
<select name="plan" class="form-control select2" id="RegistrationPlan">
<option value="" selected disabled>Select Plan</option>
<option value="1">Plan One</option>
<option value="2">Plan Two</option>
</select>
</div>
</div>
<div class="form-group">
<label for="group_name" class="col-sm-3 control-label"><small>Scholarship if Any.</small></label>
<div class="col-sm-8">
<input name="scholarship" class="form-control input-sm validate[required]" placeholder="detail About scholarship if any" maxlength="200" type="text" id="RegistrationScholarship"/> 
</div>
</div>
<hr>
<div class="form-group ">
<label for="group_name" class="col-sm-3 control-label"><small>Upload Photo</small></label>
<div class="col-sm-7">
<input type="file" name="photo"  class="form-control input-sm" placeholder="Upload 200x225px Photo" id="RegistrationPhoto"/>
</div>
</div>
<hr>
<div class="form-group clearfix" >
<label for="group_name" class="col-sm-3 control-label"><small> </small></label>
<div class="col-sm-8">
<button type="submit" class="btn btn-lg btn-primary" name="submit"><span class="fa fa-paper-plane"></span> REGISTER </button> 
</div>
</div>
</form>
                                    <?php
                                    
                                        if (isset($_POST['submit'])) {
                                            
                                            $uniqueId= time();
                                            $s="S";
                                            $uid1= $s .date('Y').$uniqueId ;
                                            
                                            //$uniqueId1= time();
                                            //$uniqueId2= time();
                                            
                                            
                                            
                                            $random_hash = substr(sha1(uniqid(rand(), true)), 6, 6);
                                            $logpwd= $random_hash ;
                                            $qual="INTER";
                                            $owner=$uid;
                                            $status="PENDING";
                                            $first_name = $_POST['first_name'];
                                            $last_name = $_POST['last_name'];
                                            $name = $first_name. ' ' .$last_name;
                                            $father_name = $_POST['father_name'];
                                            $mother_name = $_POST['mother_name'];
                                            $regnum = $_POST['regnum'];
                                            $email = $_POST['email'];
                                            $mobile = $_POST['mobile'];
                                            $alt_mobile = $_POST['alt_mobile'];
                                            $gender = $_POST['gender'];
                                            $marital_status = $_POST['marital_status'];
                                            $dob = strtr($_POST['dob'], '/', '-');
                                            //$dob = $_POST['dob'];
                                            $dob = date("Y-m-d",strtotime($dob));
                                            $corres_address = $_POST['corres_address'];
                                            $corres_state = $_POST['corres_state'];
                                            $corres_dist = $_POST['corres_dist'];
                                            $corres_pin = $_POST['corres_pin'];
                                            $corres_country = $_POST['corres_country'];
                                            $perm_address = $_POST['perm_address'];
                                            $perm_state = $_POST['perm_state'];
                                            $perm_dist = $_POST['perm_dist'];
                                            $perm_pin = $_POST['perm_pin'];
                                            $perm_country = $_POST['perm_country'];
                                            $experiance = $_POST['experiance'];
                                            $course_name = $_POST['course_name'];
                                            $plan = $_POST['plan'];
                                            $scholarship = $_POST['scholarship'];
                                            $create_date = date('Y-m-d');
                                            $null=null;
                                            

                                            if ($first_name != null && $last_name != null  && $email != null) {
                                                //Check & Upload Sub Cat Image 
                                                $errors_cat_image = array();
                                                $cat_image_file_name = $_FILES['photo']['name'];
                                                $cat_image_file_size = $_FILES['photo']['size'];
                                                $cat_image_file_tmp = $_FILES['photo']['tmp_name'];
                                                $imgData = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
                                                $imageProperties = getimageSize($_FILES['photo']['tmp_name']);
        


                                                if ($cat_image_file_size > 2097152) {
                                                    $errors_cat_image[] = 'File size must be exactely 2 MB or Less  for User Image';
                                                }

                                                if (empty($errors_cat_image) == true) { 
                                                    $insert_cat = mysqli_query($con, "insert into stud(`uid`, `logid`, `logpwd`, `name`, `fname`, `mname`, `cell`, `mail`, `dob` ,`gender`, `qual`, `address`, `city`, `sub_district`, `district`, `state`, `country`, `postal_code`, `photo`, `user_type`, `owner_id`, `status`) 
                                                    values('$uid1','$email','$logpwd','$name','$father_name','$mother_name','$mobile','$email','$dob', '$gender', '$qual', '$perm_address', '$perm_dist', '$perm_dist', '$perm_dist', '$perm_state', '$perm_country', '$perm_pin', '$imgData', '$experiance', '$owner', '$status' )");
                                                    $insert_course = mysqli_query($con, "insert into course(`uid`, `slno`, `reg_no`, `reg_date`, `course`, `duration`, `center`, `center_code`, `practical`, `written`, `assignment`, `viva`, `percentage`, `grade`, `issue_date`, `status`)
                                                    values('$uid1', '$null', '$regnum', '$create_date', '$course_name', '$null', '".$res1['f_center']."', '".$res1['f_code']."', '$null', '$null', '$null', '$null', '$null', '$null', '$null', '$status')");
                                                    
                                                    if ($insert_cat) {

                                                        echo '<div class="card-footer text-center">
                                  <p style="color:green">New Registration Added</p>
                                </div>';
                                                    } else {
                                                        echo '<div class="card-footer text-center">
                                  <p style="color:red">Failed to Add User!</p>
                                </div>';
                                                        echo("Error description: " . mysqli_error($con));
                                                    }
                                                } 
                                                
                                                else {
                                                    echo '<div class="card-footer text-center">
                                  <p style="color:red">Please Select Valid Image!</p>
                                </div>';
                                                }
                                                
                                            }
                                            
                                            else {
                                                echo '<div class="card-footer text-center">
                                  <p style="color:red">Please Fill All Data</p>
                                </div>';
                                            }
                                        }
                                ?>
</div>
</div>
</div>
</div>
</div>

</div> 
</section>

<script type="text/javascript">
    $(document).ready(function(){
    $('#post_req').validationEngine();
    
});
</script>


 <footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-5">
                    <p >Copyright &copy; <span>2022</span> Ashoka India</p>
                </div>
                 <div class="col-sm-3 wow bounceIn">
                    Powered by: <a href="https://www.microcen.com" title="Website Application Developer" target="_blank">Microcen Web Technology </a>
                 </div>
            </div>
        </div>
    </footer>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/owl.carousel.min.js"></script>
	<script type="text/javascript" src="js/wow.min.js"></script>
	<script type="text/javascript" src="js/mousescroll.js"></script>
	<script type="text/javascript" src="js/main.js"></script>
	<script type="text/javascript" src="js/smoothscroll.js"></script>
	<script type="text/javascript" src="js/jquery.prettyPhoto.js"></script>
	<script type="text/javascript" src="js/jquery.isotope.min.js"></script>
	<script type="text/javascript" src="js/jquery.inview.min.js"></script>
</body>
</html>