<?php

header("Location: login.php");

?>