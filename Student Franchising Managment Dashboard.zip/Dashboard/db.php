<?php

    $con = mysqli_connect('localhost','ashokain_ecu','rY#Z*l}Z,a!M','ashokain_ecu');
    
    if (mysqli_connect_errno()){
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
?>

