
<?php
    sleep(1);
        include_once '../../db1.php';
        
                $uid = $_POST['uid'];
                $code = $_POST['code'];
                $center = $_POST['center'];
                $address = $_POST['address'];
                $phone = $_POST['phone'];
                $email = $_POST['email'];
                $rdate = $_POST['rdate'];
                $owner = $_POST['owner'];
                
        
        $sql = "INSERT INTO  franchisee (f_uid , f_code , f_center , f_address , f_phone , f_email , f_rdate , f_owner) VALUES ('$uid','$code','$center','$address','$phone','$email','$rdate','$owner')";
                    
        $stmt=$con->prepare($sql);
        $stmt->execute();
?>



