<?php
    include("../auth_session.php");
    require('../db.php');
?>

<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://codepen.io/skjha5993/pen/bXqWpR.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <title>Add FRANCHISEE</title>
    <style>
        label {
            font-weight: 600;
            color: #555;
            }
        body {
              background: #c8efcd;
            }
    </style>
</head>
<body>
    
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="franchisee_form.php"><svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" fill="currentColor" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
  <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zm3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5z"/>
</svg></a>
</nav>
    <br>   
    <div class="container">
        <form method="POST" action=""  id="contactForm"  name="contactForm">
        <div class="row jumbotron">
            
            <!--<div class="col-sm-6 form-group">
                <label for="Country">Country</label>
                    <select class="form-control custom-select browser-default">
                        <option value="Afghanistan">Afghanistan</option>
                        <option value="Åland Islands">Åland Islands</option>
                        <option value="Albania">Albania</option>
                        <option value="Algeria">Algeria</option>
                        <option value="Zambia">Zambia</option>
                        <option value="Zimbabwe">Zimbabwe</option>
                    </select>
            </div>-->
            
            <!--<div class="col-sm-6 form-group">
                <label for="Date">Date Of Birth</label>
                <input type="Date" name="dob" class="form-control" id="Date" placeholder="" required>
            </div>-->
            
            <!--<div class="col-sm-6 form-group">
                <label for="sex">Gender</label>
                <select id="sex" class="form-control browser-default custom-select">
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="unspesified">Unspecified</option>
            </select>
            </div>-->
            
            <!--<div class="col-sm-2 form-group">
                <label for="cod">Country code</label>
                  <select class="form-control browser-default custom-select">
                    <option data-countryCode="US" value="1" selected>USA (+1)</option>
                    <option data-countryCode="GB" value="44">UK (+44)</option>
                    <option disabled="disabled">Other Countries</option>
                    <option data-countryCode="DZ" value="213">Algeria (+213)</option>
                    <option data-countryCode="AD" value="376">Andorra (+376)</option>
                    <option data-countryCode="AO" value="244">Angola (+244)</option>
                  </select>
            </div>-->
            
            <!--<div class="col-sm-4 form-group">
                <label for="tel">Phone</label>
                <input type="tel" name="phone" class="form-control" id="tel" placeholder="Enter Your Contact Number." required>
            </div>-->
            
            <div class="col-sm-6 form-group">
                <label for="name-f">Franchisee User ID</label>
                <input type="text" class="form-control" name="uid" id="name-f" placeholder="Enter your User ID." required>
            </div>
            <div class="col-sm-6 form-group">
                <label for="name-l">Franchisee Code</label>
                <input type="text" class="form-control" name="code" id="name-l" placeholder="Enter your Code." required>
            </div>
            <div class="col-sm-6 form-group">
                <label for="pass">Franchisee Center</label>
                <input type="text" class="form-control" name="center" id="pass" placeholder="Enter your Center." required>
            </div>
            <div class="col-sm-6 form-group">
                <label for="pass2">Franchisee Address</label>
                <input type="text" class="form-control" name="address" id="pass2" placeholder="Enter your Address." required>
            </div>
            <div class="col-sm-6 form-group">
                <label for="name-f">Franchisee Phone</label>
                <input type="number" class="form-control" name="phone" id="name-f" placeholder="Enter your Phone." required>
            </div>
            <div class="col-sm-6 form-group">
                <label for="name-l">Franchisee Email</label>
                <input type="text" class="form-control" name="email" id="name-l" placeholder="Enter your Email." required>
            </div>
            <div class="col-sm-6 form-group">
                <label for="pass">Franchisee Date</label>
                <input type="Date" class="form-control" name="rdate" id="pass" placeholder="Enter Date." required>
            </div>
            <div class="col-sm-6 form-group">
                <label for="pass2">Franchisee Owner ID</label>
                <input type="text" class="form-control" name="owner" id="pass2" placeholder="Enter Owner ID." required>
            </div>
            <div class="col-sm-12">
                <input type="checkbox" class="form-check d-inline" id="chb" required><label for="chb" class="form-check-label">&nbsp;I accept all terms and conditions.
                </label>
            </div>
            
            <div id="thank_you_msg" style="color: red; font-family: auto; font-weight: bold; margin-top: 5px;"></div>

            <div class="col-sm-12 form-group mb-0">
               <button class="btn btn-primary float-right" name="submit" id="btn">Submit Now</button>
            </div>
            
        </div>
        </form>
    </div>

<script>	
	jQuery('#contactForm').on('submit',function(e){
			jQuery('#btn').val('Please wait...');
			jQuery('#btn').attr('disabled',true);
			jQuery.ajax({
				url:'./Ajax/franchisee.php',
				type:'post',
				data:jQuery('#contactForm').serialize(),
				success:function(result){
					jQuery('#thank_you_msg').html('Thanks for add new franchisee.');
					jQuery('#contactForm')['0'].reset();
					jQuery('#btn').val('Submit Now');
					jQuery('#btn').attr('disabled',false);
				}
			});
			e.preventDefault();
		});
</script>

</body>
</html>